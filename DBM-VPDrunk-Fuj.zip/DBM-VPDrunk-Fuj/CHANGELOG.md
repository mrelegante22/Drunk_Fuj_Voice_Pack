# <DBM> Voicepack Demo

## [DBM-VPDemo-V13](https://github.com/DeadlyBossMods/DBM-Voicepack-Demo/tree/DBM-VPDemo-V13) (2022-11-15)
[Full Changelog](https://github.com/DeadlyBossMods/DBM-Voicepack-Demo/compare/DBM-VPDemo-V12...DBM-VPDemo-V13) [Previous Releases](https://github.com/DeadlyBossMods/DBM-Voicepack-Demo/releases)

- Bump TOC files  
- Resample recent media and bump voice pack version  
- Create movetopillar.ogg  
- Bump TOC files  
- Create pushbackincoming.ogg  
- Fix media packs so they also package for wrath  
- TOC bumps  
- Update filenames for v12 (#4)  
- Update !VoiceText.txt  
- Create chainboss.ogg  
- toc bump  
- forgot to bump classic toc  
- Merge pull request #3 from Hollicsh/patch-1  
    Update DBM-VPDemo.toc  
- Update DBM-VPDemo.toc  
    bump BCC toc  
- resample pullin  
- Create pullin.ogg  
- Update DBM-VPDemo.toc  
    Added  ## Title-ruRU and  ## X-DBM-Voice-Name-ruRU  
- Resample latest audio and bump toc  
- useextraaction & dontmove  
- Bump classic interface version  
- Resample audio of new files  
- add harmonic & melodic  
- Create bombyou.ogg  
- Resample  
     - All audio changed from fake stereo (both tracks were identicle) to mono  
     - All audio should have smaller file size  
     - All audio should be slightly louder.  
- Update !HowTo.txt  
- Cleaner README  